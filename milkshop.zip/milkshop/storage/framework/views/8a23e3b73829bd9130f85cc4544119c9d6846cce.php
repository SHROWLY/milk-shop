<?php $__env->startSection('content'); ?>
<div class="container" style="padding-bottom: 15px;">
    <h3>Areas:</h3>
<?php $__currentLoopData = $areas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $area): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<a href="/usersbyarea/<?php echo e($area->id); ?>/view" type="button" value="<?php echo e($area->id); ?>" class="btn btn-primary" ><?php echo e($area->name); ?></a>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
<div class="container">
    <div class="row">
    <?php $__currentLoopData = $finds; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $body): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="col-xs-12 col-sm-6 col-md-6">
            <div class="well well-sm">
                <div class="row">
                    <div class="col-sm-6 col-md-4">
                    <?php if($body->avatar): ?> 
                        <img src="<?php echo e($body->avatar); ?>" alt="" class="img-rounded img-responsive" style="width: 200px;"/>
                    <?php endif; ?>
                    </div>
                    <div class="col-sm-6 col-md-8">
                        <h4><?php echo e($body->first_name); ?> <?php echo e($body->last_name); ?></h4>
                        <p>
                            <i class="glyphicon glyphicon-user"></i><?php echo e($body->username); ?>

                            <br />
                            <i class="glyphicon glyphicon-time"></i><?php echo e($body->created_at); ?>

                            <br />
                        </p>
                        <!-- Split button -->
                        <a href="/userposts=<?php echo e($body->id); ?>" type="button" class="btn btn-info" >View Person</a>
                    </div>
                </div>
            </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('header-styles'); ?>
<style type="text/css">
            .glyphicon {  margin-bottom: 10px;margin-right: 10px;}
            small {
            display: block;
            line-height: 1.428571429;
            color: #999;
            }
</style>
<link rel="stylesheet" href="//cdnjs.cloudflare.com/ajax/libs/chosen/1.4.2/chosen.min.css">
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>