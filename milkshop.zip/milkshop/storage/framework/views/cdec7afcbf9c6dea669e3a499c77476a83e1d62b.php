<?php $__env->startSection('content'); ?>

 <div class="container">
      <div class="row">
        <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 col-xs-offset-0 col-sm-offset-0 col-md-offset-0 col-lg-offset-0 toppad" >
          
          
          <div class="panel panel-info">
            <div class="panel-heading">
              <h3 class="panel-title"><?php echo e($house->address); ?></h3>
            </div>
            <div class="panel-body">
              <div class="row">
                <div class="col-md-3 col-lg-3 " align="center"> <img alt="User Pic" src="<?php echo e($house->photo); ?>" class=" img-responsive"> </div>
                <div class=" col-md-9 col-lg-9 ">
                  <table class="table table-user-information">
                    <tbody>
                      
                      <tr>
                        <td>Name:</td>
                        <td><?php echo e($house->firstname); ?> <?php echo e($house->lastname); ?></td>
                      </tr>
                      <tr>
                        <td>Area:</td>
                        <td><?php echo e($house->area->name); ?></td>
                      </tr>
                      
                      <tr>
                        <tr>
                          <td>Phone:</td>
                          <td><?php echo e($house->phone); ?> <?php if($house->phone1): ?><br><?php echo e($house->phone1); ?> <?php endif; ?></td>
                        </tr>
                        <tr>
                          <td>Created At:</td>
                          <td><?php echo e($house->created_at); ?></td>
                        </tr>
                        <a href="survey/<?php echo e($house->id); ?>">Survey</a>
                      </tr>
                      
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
            <div class="panel-footer">
              <h4>House Analytics:</h4>
            </div>
            
          </div>
        </div>
      </div>
    </div>
       <!-- panel preview -->
       <div class="container">
       <div class="row">
        <div class="col-sm-8 ">
            <h4>Add payment:</h4>
            <div class="panel panel-default">
                <div class="panel-body form-horizontal payment-form">
                <form class="form-horizontal" role="form" method="POST" action="/profile=<?php echo e($house->id); ?>">
                        <?php echo e(csrf_field()); ?>

                    <?php if(count($errors) > 0): ?>
                      <div class="alert alert-danger">
                          <ul>
                              <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                  <li><?php echo e($error); ?></li>
                              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                          </ul>
                      </div>
                  <?php endif; ?>
                    <div class="form-group">
                        <label for="quantity" class="col-sm-3 control-label">Quantity</label>
                        <div class="col-sm-9">
                            <input type="number" class="form-control" id="quantity" name="quantity">
                        </div>
                    </div>
                    <div class="form-group">
                        <label for="amount" class="col-sm-3 control-label">Amount</label>
                        <div class="col-sm-9">
                            <input type="number" class="form-control" id="amount" name="amount">
                        </div>
                    </div>
                    <div class="form-group">
                        <div class="col-sm-12 text-right">
                            <button type="submit" class="btn btn-default preview-add-button">
                                <span class="glyphicon glyphicon-plus"></span> Add
                            </button>
                        </div>
                    </div>
                    </form>
                </div>
            </div>            
        </div> <!-- / panel preview -->
        </div>
        </div>
<div class="container">
  <div class="row">
        <div class="col-sm-12">
        <?php if(!empty($sum)): ?>
        <h3>Bill for this Month: <?php echo e($sum); ?> Rs</h3>
        <?php endif; ?>
        <?php if(!empty($sumpast)): ?>
        <h3>Bill for past Month: <?php echo e($sumpast); ?> Rs</h3>
        <?php endif; ?>
        <?php if(!empty($quantitythismonth)): ?>
        <h3>Quantity for this Month: <?php echo e($quantitythismonth); ?> Liters</h3>
        <?php endif; ?>
        <?php if(!empty($quantitypastmonth)): ?>
        <h3>Quantity for past Month: <?php echo e($quantitypastmonth); ?> Liters</h3>
        <?php endif; ?>
            <h4>Preview:</h4>
                <div class="col-xs-12">
                    <div class="table-responsive">
                        <table class="table preview-table">
                        <thead>
                                <tr>                                   
                                    <th>Quantity</th>
                                    <th>Amount (per liter)</th>
                                    <th>Date</th>
                                    <th>Total</th>
                                </tr>
                         </thead>
                         <tbody>  
                              <?php $__currentLoopData = $house->billings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $body): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                              <tr>
                                <td><?php echo e($body->quantity); ?> Litres</td>
                                <td><?php echo e($body->price); ?> Rs</td>
                                <td><?php echo e($body->created_at); ?></td>
                                <td><?php echo e($body->total); ?> Rs</td>
                              </tr> 
                               <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                          </tbody>       
                              <!-- preview content goes here-->
                        </table>
                    </div>                            
                </div>
            </div>
        </div>    
  </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('header-styles'); ?>
<link rel="stylesheet" type="text/css" href="//netdna.bootstrapcdn.com/font-awesome/4.1.0/css/font-awesome.min.css">
<style type="text/css">
body {
font-family: "Helvetica Neue",Helvetica,Arial,sans-serif;
font-size: 14px;
line-height: 1.42857143;
background-color: #F1F1F1;
}
.glyphicon {  margin-bottom: 10px;margin-right: 10px;}
small {
            display: block;
            line-height: 1.428571429;
            color: #999;
            }

.panel-shadow {
    box-shadow: rgba(0, 0, 0, 0.3) 7px 7px 7px;
}
.panel-white {
  border: 1px solid #dddddd;
}
.panel-white  .panel-heading {
  color: #333;
  background-color: #fff;
  border-color: #ddd;
}
.panel-white  .panel-footer {
  background-color: #fff;
  border-color: #ddd;
}

.post .post-heading {
  height: 95px;
  padding: 20px 15px;
}
.post .post-heading .avatar {
  width: 60px;
  height: 60px;
  display: block;
  margin-right: 15px;
}
.post .post-heading .meta .title {
  margin-bottom: 0;
}
.post .post-heading .meta .title a {
  color: black;
}
.post .post-heading .meta .title a:hover {
  color: #aaaaaa;
}
.post .post-heading .meta .time {
  margin-top: 8px;
  color: #999;
}
.post .post-image .image {
  width: 100%;
  height: auto;
}
.post .post-description {
  padding: 15px;
}
.post .post-description p {
  font-size: 14px;
}
.post .post-description .stats {
  margin-top: 20px;
}
.post .post-description .stats .stat-item {
  display: inline-block;
  margin-right: 15px;
}
.post .post-description .stats .stat-item .icon {
  margin-right: 8px;
}
.post .post-footer {
  border-top: 1px solid #ddd;
  padding: 15px;
}
.post .post-footer .input-group-addon a {
  color: #454545;
}
.post .post-footer .house-list {
  padding: 0;
  margin-top: 20px;
  list-style-type: none;
}
.post .post-footer .house-list .comment {
  display: block;
  width: 100%;
  margin: 20px 0;
}
.post .post-footer .house-list .comment .avatar {
  width: 35px;
  height: 35px;
}
.post .post-footer .house-list .comment .comment-heading {
  display: block;
  width: 100%;
}
.post .post-footer .house-list .comment .comment-heading .user {
  font-size: 14px;
  font-weight: bold;
  display: inline;
  margin-top: 0;
  margin-right: 10px;
}
.post .post-footer .house-list .comment .comment-heading .time {
  font-size: 12px;
  color: #aaa;
  margin-top: 0;
  display: inline;
}
.post .post-footer .house-list .comment .comment-body {
  margin-left: 50px;
}
.post .post-footer .house-list .comment > .house-list {
  margin-left: 50px;
}
</style>
<link rel="stylesheet" href="//cdnjs.cloudflare.com/ajax/libs/chosen/1.4.2/chosen.min.css">
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>