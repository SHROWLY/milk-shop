<?php $__env->startSection('content'); ?>
<div class="container">
  <h1 class="page-header">Edit Profile</h1>
    <!-- left column -->
    <form enctype="multipart/form-data" action="/userprofile" method="POST">
    <?php echo e(csrf_field()); ?>

    <div class="col-md-12">
      <div class="text-center">
        <img src="<?php echo e($user->avatar); ?>" style="width:200px;">
        <h6>Upload a different photo...</h6>
        <input type="file" name="avatar" class="text-center center-block well well-sm">
        <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
      </div>
      </div>
    <!-- edit form column -->
    <div class="col-md-12 personal-info">
      <div class="alert alert-info alert-dismissable">
        <a class="panel-close close" data-dismiss="alert">×</a> 
        <i class="fa fa-coffee"></i>
        Edit your profile using the fields below:
      </div>
      <h3>Personal info</h3>
      <div class="row">
        <div class="form-group<?php echo e($errors->has('first_name') ? ' has-error' : ''); ?>">
          <label class="col-md-3">First name:</label>
          <div class="col-md-8">
            <input class="form-control" name="first_name" value="<?php echo e($user->first_name); ?>" type="text">
            <?php if($errors->has('first_name')): ?>
            <span class="help-block">
            <strong><?php echo e($errors->first('first_name')); ?></strong>
            </span>
            <?php endif; ?>
          </div>
        </div>
        </div>
        <div class="row">
        <div class="form-group<?php echo e($errors->has('last_name') ? ' has-error' : ''); ?>">
          <label class="col-md-3">Last name:</label>
          <div class="col-md-8">
            <input class="form-control" name="last_name" value="<?php echo e($user->last_name); ?>" type="text">
                  <?php if($errors->has('last_name')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('last_name')); ?></strong>
                                    </span>
                                <?php endif; ?>            
          </div>
        </div>
        </div>
        <div class="row">
        <div class="form-group<?php echo e($errors->has('username') ? ' has-error' : ''); ?>">
          <label class="col-md-3">Username:</label>
          <div class="col-md-8">
            <input class="form-control" id="username" name="username" placeholder="Type in your new Username" type="text">
            <?php if($errors->has('username')): ?>
                <span class="help-block">
              <strong><?php echo e($errors->first('username')); ?></strong>
              </span>
              <?php endif; ?>
          </div>
        </div>
        </div>
        <div class="row">
        <div class="form-group<?php echo e($errors->has('email') ? ' has-error' : ''); ?>">
          <label class="col-md-3">Email:</label>
          <div class="col-md-8">
            <input class="form-control" name="email" value="" placeholder="Type in your new Email" type="text">
            <?php if($errors->has('email')): ?>
                <span class="help-block">
              <strong><?php echo e($errors->first('email')); ?></strong>
              </span>
             <?php endif; ?>
          </div>
          </div>
        </div>
        <div class="row">
        <div class="form-group">
          <label class="col-md-3">Description:</label>
          <div class="col-md-8">
             <textarea name="body" rows="6" cols="50" placeholder="Tell us about Yourself"><?php echo e($user->description); ?></textarea>
          </div>
        </div>
        </div>
        <div class="row">
        <div class="form-group">
         <label class="col-md-3"></label>
          <div class="col-md-8">
            <input class="btn btn-success" type="submit" value="Save Changes">
             <a href="/userview" type="button" class="btn btn-warning">Back</a>
            <span></span>
          </div>
        </div>
        <div class="row">
        <div class="form-group">
          <label class="col-md-3"></label>
          <div class="col-md-8">
          </div>
        </div>
        </div>
    </div>
</form>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('header-styles'); ?>
<style type="text/css">
  .form-group{
    margin-top: 15px;
  }
</style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('footer-scripts'); ?>
   <script src="//code.jquery.com/jquery-1.11.3.min.js"></script>
   <script type="text/javascript">
       jQuery(function($){
    $('#username').keyup(function(e){
        if (e.which === 32) {
            var str = $(this).val();
            str = str.replace(/\s/g,'');
            $(this).val(str);            
        }
    }).blur(function() {
        var str = $(this).val();
        str = str.replace(/\s/g,'');
        $(this).val(str);            
    });
});
   </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>