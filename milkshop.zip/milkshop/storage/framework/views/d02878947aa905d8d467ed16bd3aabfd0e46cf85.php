<?php $__env->startSection('content'); ?>
<div class="container" style="margin-top: 20px; margin-bottom: 20px;">
  <div class="row">
    <div class="col-md-4 text-center">
          <a href="<?php echo e($user->avatar); ?>"><img src="<?php echo e($user->avatar); ?>" style="width: 300px; border: 6px solid white;" /></a>
    </div>
        <div class="col-md-8  col-xs-12">
           <div class="header">
                <h2><?php echo e($user->first_name); ?> <?php echo e($user->last_name); ?></h2>
                @<span><?php echo e($user->username); ?></span><br><br>
                <span><?php echo e($user->description); ?></span>
           </div>
        </div>
    </div>
    <h1>Houses:</h1>
        <div class="row">
   <?php $__currentLoopData = $houses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $house): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="col-xs-12 col-sm-6 col-md-6">
                <div class="row">
                    <div class="col-sm-6 col-md-4">
                    <?php if($house->photo): ?> 
                        <img src="/<?php echo e($house->photo); ?>" alt="" class="img-rounded img-responsive" style="width: 200px;"/>
                    <?php endif; ?>
                    </div>
                    <div class="col-sm-6 col-md-8">
                        <h4><?php echo e($house->address); ?></h4>
                        <h5><?php echo e($house->firstname); ?> <?php echo e($house->lastname); ?></h5>
                        <a href="/housesbyarea/<?php echo e($house->area->id); ?>/view"><small><cite><i class="glyphicon glyphicon-map-marker">
                        </i> <?php echo e($house->area->name); ?></cite></small></a>
                        <p>
                            <i class="glyphicon glyphicon-phone"></i> <?php echo e($house->phone); ?> <?php if($house->phone1): ?>/ <?php echo e($house->phone1); ?> <?php endif; ?>
                            <br />
                            <i class="glyphicon glyphicon-time"></i><?php echo e($house->created_at); ?>

                            <br />
                            <i class="glyphicon glyphicon-tags"></i>
                            <?php $__currentLoopData = $house->tags; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $single): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <a href="/home/tag=<?php echo e($single); ?>"><?php echo e($single); ?></a>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </p>

                        <!-- Split button -->
                        <a href="/profile=<?php echo e($house->id); ?>" type="button" class="btn btn-info" >View Person</a>
                        <a href="/home/<?php echo e($user->id); ?>/edit" type="button" class="btn btn-info" >Edit</a>
                        <a href="/home/<?php echo e($user->id); ?>/delete" type="button" class="btn btn-danger" >Delete</a>
                        
                    </div>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
    </div>   
<?php $__env->stopSection(); ?>
<?php $__env->startSection('header-styles'); ?>
<link href='http://fonts.googleapis.com/css?family=Open+Sans' rel='stylesheet' type='text/css'>
<link href="//maxcdn.bootstrapcdn.com/font-awesome/4.2.0/css/font-awesome.min.css" rel="stylesheet">
<style type="text/css">
  *{
    font-family: 'Open Sans', sans-serif;
}

.well {
    margin-top:-20px;
    background-color:#007FBD;
    border:2px solid #0077B2;
    text-align:center;
    cursor:pointer;
    font-size: 25px;
    padding: 15px;
    border-radius: 0px !important;
}

.well:hover {
    margin-top:-20px;
    background-color:#0077B2;
    border:2px solid #0077B2;
    text-align:center;
    cursor:pointer;
    font-size: 25px;
    padding: 15px;
    border-radius: 0px !important;
    border-bottom : 2px solid rgba(97, 203, 255, 0.65);
}

house {
font-family: "Helvetica Neue",Helvetica,Arial,sans-serif;
font-size: 14px;
line-height: 1.42857143;
background: #F1F0F0;
}

.follow_btn {
    text-decoration: none;
    position: absolute;
    left: 35%;
    top: 42.5%;
    width: 35%;
    height: 15%;
    background-color: #007FBE;
    padding: 10px;
    padding-top: 6px;
    color: #fff;
    text-align: center;
    font-size: 20px;
    border: 4px solid #007FBE;
}

.follow_btn:hover {
    text-decoration: none;
    position: absolute;
    left: 35%;
    top: 42.5%;
    width: 35%;
    height: 15%;
    background-color: #007FBE;
    padding: 10px;
    padding-top: 6px;
    color: #fff;
    text-align: center;
    font-size: 20px;
    border: 4px solid rgba(255, 255, 255, 0.8);
}
.glyphicon {  margin-bottom: 10px;margin-right: 10px;}
            small {
            display: block;
            line-height: 1.428571429;
            color: #999;
            }
.header{
    color : #808080;
    margin-left:10%;
    margin-top:70px;
}

.picture{
    height:150px;
    width:150px;
    position:absolute;
    top: 75px;
    left:-75px;
}

.picture_mob{
    position: absolute;
    width: 35%;
    left: 35%;
    bottom: 70%;
}

.btn-style{
    color: #fff;
    background-color: #007FBE;
    border-color: #adadad;
    width: 33.3%;
}

.btn-style:hover {
    color: #333;
    background-color: #3D5DE0;
    border-color: #adadad;
    width: 33.3%;
   
}


@media (max-width: 767px) {
    .header{
        text-align : center;
    }
    
    
    
    .nav{
        margin-top : 30px;
    }
}
</style>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>