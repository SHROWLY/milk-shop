<?php $__env->startSection('content'); ?>
<div class="container">
        <div class="row">
        <div class="col-md-10 col-md-offset-1">
<div class="panel panel-default">
  <div class="panel-heading">Edit Comment</div>
  <div class="panel-body">
<form method="POST" action="/commentedit=<?php echo e($comment->id); ?>">
  <?php echo e(csrf_field()); ?>

<?php if(count($errors) > 0): ?>
    <div class="alert alert-danger">
        <ul>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
<?php endif; ?>
  <div class="form-group">
    <label>First Name:</label>
    <input type="text" class="form-control" name="name" value="<?php echo e($comment->name); ?>" placeholder="Complete Name" style="width: 55%;">
  </div>
  <div class="form-group">
    <label> Email:</label>
    <input type="text" class="form-control" name="email" value="<?php echo e($comment->email); ?>" placeholder="Email Address" style="width: 45%;">
  </div>
  <div class="form-group">
    <label>Comment:</label><br>
    <textarea name="comment" rows="6" cols="50" placeholder="Enter Comment"><?php echo e($comment->comment); ?></textarea>
  </div>
  <input class="btn btn-success" type="submit" value="Submit">
  </form>
  </div>
  </div>
  <br>
     </div>
   </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('header-styles'); ?>
<link rel="stylesheet" type="text/css" href="//netdna.bootstrapcdn.com/font-awesome/4.1.0/css/font-awesome.min.css">
<style type="text/css">
body {
font-family: "Helvetica Neue",Helvetica,Arial,sans-serif;
font-size: 14px;
line-height: 1.42857143;
background-color: #F1F1F1;
}
.glyphicon {  margin-bottom: 10px;margin-right: 10px;}
small {
            display: block;
            line-height: 1.428571429;
            color: #999;
            }

</style>
<link rel="stylesheet" href="//cdnjs.cloudflare.com/ajax/libs/chosen/1.4.2/chosen.min.css">
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>