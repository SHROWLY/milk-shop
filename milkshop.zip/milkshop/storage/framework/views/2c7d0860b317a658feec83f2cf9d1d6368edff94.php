<!DOCTYPE html>
<html lang="en">

<head>

    <title>Edit Person Profile</title>
    <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">
            <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">
             <link rel="stylesheet" href="//cdnjs.cloudflare.com/ajax/libs/chosen/1.4.2/chosen.min.css">
             <link href="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.3/css/select2.min.css" rel="stylesheet" />

<style type="text/css">
.choiceChosen, .productChosen {
  width: 200px ;
}
.row {
  margin-bottom:15px;}
</style>
</head>
<body>
<div class="container">
<h1 class="page-header">Edit Profile</h1>
<form method="POST" action="/home/<?php echo e($finds->id); ?>/update" enctype="multipart/form-data">
  <?php echo e(csrf_field()); ?>

<?php if(count($errors) > 0): ?>
    <div class="alert alert-danger">
        <ul>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
<?php endif; ?>
<div class="col-md-12">
      <div class="text-center">
        <img src="/<?php echo e($finds->photo); ?>" style="width:200px;">
        <h6>Upload a different photo...</h6>
        <input type="file" name="photo" class="text-center center-block well well-sm">
        <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
      </div>
      </div>
  <div class="row">
  <div class="form-group" >
    <label class="col-md-3">Area:</label>
      <div class="col-md-8">
    <select name="area"  class="select2basic" style="width: 200px;">
    <?php $__currentLoopData = $areas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $area): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <option value="<?php echo e($area->id); ?>"><?php echo e($area->name); ?></option>
   <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </select>
  </div>
  </div>
  </div>
<div class="row">
  <div class="form-group">
    <label class="col-md-3">First Name:</label>
      <div class="col-md-8">
    <input type="text" class="form-control" name="firstname" value="<?php echo e($finds->firstname); ?>" placeholder="Changes First Name" >
  </div>
  </div>
  </div>
  <div class="row">
  <div class="form-group">
    <label class="col-md-3">Last Name:</label>
      <div class="col-md-8">
    <input type="text" class="form-control" value="<?php echo e($finds->lastname); ?>" name="lastname" placeholder="Change Last Name" >
  </div>
  </div>
  </div>
    <div class="row">
  <div class="form-group">
    <label class="col-md-3">Address:</label>
      <div class="col-md-8">
    <input type="text" class="form-control" value="<?php echo e($finds->address); ?>" name="address" placeholder="Change Address" >
  </div>
  </div>
  </div>
  <div class="row">
    <div class="form-group">
    <label class="col-md-3">ID Card:</label>
      <div class="col-md-8">
    <input type="text" class="form-control" value="<?php echo e($finds->idcard); ?>" name="idcard" placeholder="Add ID Card Number" >
  </div>
  </div>
  </div>
  <div class="row">
  <div class="form-group">
    <label class="col-md-3">Contact Number:</label>
      <div class="col-md-8">
    <input type="text" class="form-control" name="phone" value="<?php echo e($finds->phone); ?>" placeholder="Change Contact Number" >
    <input type="text" class="form-control" name="phone1" value="<?php echo e($finds->phone1); ?>" placeholder="Add Second Number" >
  </div>
  </div>
  </div>
  <div class="row">
  <div class="form-group">
    <label class="col-md-3">Tags:</label>
      <div class="col-md-8">
    <select name="tags[]" id="input-tags" style="width: 300px;" multiple>
       <?php $__currentLoopData = $finds->tags; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $single): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option><?php echo e($single); ?></option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </select>
  </div>
  </div>
  </div>
    <div class="row">
  <div class="form-group">
    <label class="col-md-3">Description:</label>
      <div class="col-md-8">
    <textarea name="body" rows="6" cols="50" placeholder="Enter Description"><?php echo e($finds->description); ?></textarea>
  </div>
  </div>
  </div>
  <div class="row">
  <div class="form-group">
    <label class="col-md-3"></label>
      <div class="col-md-8">
    <input class="btn btn-success" type="submit" value="Submit">
  <a href="/home" type="button" class="btn btn-warning">Back</a>
  </div>
  </div>
  </div>

  </form>
  </div>
 </body>
    <script src="//code.jquery.com/jquery-1.11.3.min.js"></script>
    <script src="//cdnjs.cloudflare.com/ajax/libs/chosen/1.4.2/chosen.jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.3/js/select2.min.js"></script>

 <script>
 $(document).ready(function() {
  $(".select2basic").select2();
});
 $("#input-tags").select2({
  tags: true
});
     </script>
 <script>
 $(document).ready(function(){
     //Chosen
   $(".choiceChosen, .productChosen").chosen({});
   //Logic
   $(".choiceChosen").change(function(){
     if($(".choiceChosen option:selected").val()=="no"){
       $(".productChosen option[value='2']").attr('disabled',true).trigger("chosen:updated");
       $(".productChosen option[value='1']").removeAttr('disabled',true).trigger("chosen:updated");
     } else {
       $(".productChosen option[value='1']").attr('disabled',true).trigger("chosen:updated");
       $(".productChosen option[value='2']").removeAttr('disabled',true).trigger("chosen:updated");
     }
   })
 });
     </script>
</html>
