<!DOCTYPE html>
<html lang="en" class="no-js">
	<head>
		<meta charset="UTF-8" />
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<title>Add Quantity</title>
	    <!-- Font Awesome -->
	    <link href="/vendors/font-awesome/css/font-awesome.min.css" rel="stylesheet">
		<link rel="stylesheet" type="text/css" href="/css/demo.css" />
		<link rel="stylesheet" type="text/css" href="/css/set1.css" />
		<link rel="stylesheet" href="/css/sweetalert.css">
		<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">
		<!--[if IE]>
  		<script src="http://html5shiv.googlecode.com/svn/trunk/html5.js"></script>
		<![endif]-->
	</head>
	<body>
		<div class="container">
<form class="form-horizontal" role="form" method="POST" action="/addquantity=<?php echo e($house->id); ?>">
                        <?php echo e(csrf_field()); ?>

           <?php if(count($errors) > 0): ?>
                    <div class="alert alert-danger">
                        <ul>
                            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li><?php echo e($error); ?></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    </div>
                <?php endif; ?>
			<section class="content">
			<div class="dy-date">
				<script type="text/javascript">
				document.write ('<h3> <span id="date-time">', new Date().toLocaleString(), '<\/span><\/h3>')
				var monthNames = ["January", "February", "March", "April", "May", "June",
				  "July", "August", "September", "October", "November", "December"
				];
				if (document.getElementById) onload = function () {
				  setInterval ("document.getElementById ('date-time').firstChild.data = new Date().toLocaleString()", 50)

				}
				</script>
			<h4><?php echo e($house->address); ?></h4>
			</div>
				<span class="input">
					<input name="quantity" required="required" type="number" class="input__field input__field--ichiro" type="text" id="input-25" />
					<label class="input__label input__label--ichiro" for="input-25">
						<span class="input__label-content input__label-content--ichiro">Add Quantity</span>
					</label>
				</span>
			</section>
			<button type="submit" class="btn btn-primary btn-lg btn-add btn-huge">Add</button>	
	</form>
			<br>
			<hr>
			<a href="<?php echo e(url('/home')); ?>" class="btn btn-default btn-lg"><i class="fa fa-arrow-left"></i> Back</a>
			<button class="btn btn-info btn-lg">Details</button>
			<a href="/survey/<?php echo e($house->id); ?>" class="btn btn-success btn-lg">Survey</a>

	
		</div><!-- /container -->
		<script src="/js/classie.js"></script>
		<script src="/js/sweetalert.min.js"></script>
		    <!-- Include this after the sweet alert js file -->
		<?php echo $__env->make('sweet::alert', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
		<script>
			(function() {
				// trim polyfill : https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/String/Trim
				if (!String.prototype.trim) {
					(function() {
						// Make sure we trim BOM and NBSP
						var rtrim = /^[\s\uFEFF\xA0]+|[\s\uFEFF\xA0]+$/g;
						String.prototype.trim = function() {
							return this.replace(rtrim, '');
						};
					})();
				}

				[].slice.call( document.querySelectorAll( 'input.input__field' ) ).forEach( function( inputEl ) {
					// in case the input is already filled..
					if( inputEl.value.trim() !== '' ) {
						classie.add( inputEl.parentNode, 'input--filled' );
					}

					// events:
					inputEl.addEventListener( 'focus', onInputFocus );
					inputEl.addEventListener( 'blur', onInputBlur );
				} );

				function onInputFocus( ev ) {
					classie.add( ev.target.parentNode, 'input--filled' );
				}

				function onInputBlur( ev ) {
					if( ev.target.value.trim() === '' ) {
						classie.remove( ev.target.parentNode, 'input--filled' );
					}
				}
			})();
		</script>
	</body>
</html>
