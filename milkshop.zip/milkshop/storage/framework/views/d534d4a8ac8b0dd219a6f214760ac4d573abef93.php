<?php $__env->startSection('content'); ?>
<div class="container" style="padding-bottom: 15px;">
    <h3>Category:</h3>
<?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<a href="categoryview/<?php echo e($category->id); ?>/view" type="button" value="<?php echo e($category->id); ?>" class="btn btn-primary" ><?php echo e($category->name); ?></a>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
<div class="container">
    <div class="row">
    <?php $__currentLoopData = $finds; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $body): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="col-xs-12 col-sm-6 col-md-6">
            <div class="well well-sm">
                <div class="row">
                    <div class="col-sm-6 col-md-4">
                    <?php if($body->photo): ?> 
                        <img src="<?php echo e($body->photo); ?>" alt="" class="img-rounded img-responsive" style="width: 200px;"/>
                    <?php endif; ?>
                    </div>
                    <div class="col-sm-6 col-md-8">
                        <h4><?php echo e($body->firstname); ?> <?php echo e($body->lastname); ?></h4>
                        <small><cite><i class="glyphicon glyphicon-map-marker">
                        </i> <?php echo e($body->area->name); ?></cite></small>
                        <p>
                            <i class="glyphicon glyphicon-phone"></i> <?php echo e($body->phone); ?>

                            <br />
                            <a href="/categoryview/<?php echo e($body->category->id); ?>/view"><i class="glyphicon glyphicon-globe"></i><?php echo e($body->category->name); ?></a>
                            <br />
                            <i class="glyphicon glyphicon-user"><a href="userposts=<?php echo e($body->user->id); ?>"></i><?php echo e($body->user->username); ?></a>
                            <br />
                            <i class="glyphicon glyphicon-time"></i><?php echo e($body->created_at); ?>

                            <br />
                            <i class="glyphicon glyphicon-tags"></i>
                            <?php $__currentLoopData = $body->tags; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $single): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <a href="/home/tag=<?php echo e($single); ?>"><?php echo e($single); ?></a>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </p>
                        <!-- Split button -->
                        <a href="/profile=<?php echo e($body->id); ?>" type="button" class="btn btn-info" >View Person</a>
                        <a href="/home/<?php echo e($body->id); ?>/edit" type="button" class="btn btn-info" >Edit</a>
                        <a href="/home/<?php echo e($body->id); ?>/delete" type="button" class="btn btn-danger" >Delete</a>
                        
                    </div>
                </div>
            </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('header-styles'); ?>
<style type="text/css">
            .glyphicon {  margin-bottom: 10px;margin-right: 10px;}
            small {
            display: block;
            line-height: 1.428571429;
            color: #999;
            }
</style>
<link rel="stylesheet" href="//cdnjs.cloudflare.com/ajax/libs/chosen/1.4.2/chosen.min.css">
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>