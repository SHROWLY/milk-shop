<!DOCTYPE html>
<html lang="en">

<head>

    <title>Add New Person</title>
    <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">
            <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">
             <link href="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.3/css/select2.min.css" rel="stylesheet" />
</head>
<body>
<div class="container">
    <div class="row">
        <div class="col-md-10 col-md-offset-1">
<div class="panel panel-default">
  <div class="panel-heading">Add New Person</div>
  <div class="panel-body">
<form method="POST" action="/add" enctype="multipart/form-data">
  <?php echo e(csrf_field()); ?>

<?php if(count($errors) > 0): ?>
    <div class="alert alert-danger">
        <ul>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
<?php endif; ?>
  <div class="form-group">
<label>Image Upload:</label>
    <input type="file" name="photo" id="form-control">
</div>
<div class="form-group" >
    <label>Category:</label>
    <select name="category"  class="select2basic" style="width: 200px;">
    <?php $__currentLoopData = $finds; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <option value="<?php echo e($category->id); ?>"><?php echo e($category->name); ?></option>
   <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</select>
  </div>
  <div class="form-group" >
    <label>Area:</label>
    <select name="area"  class="select2basic" style="width: 200px;">
    <?php $__currentLoopData = $areas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $area): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <option value="<?php echo e($area->id); ?>"><?php echo e($area->name); ?></option>
   <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</select>
  </div>
  <div class="form-group">
    <label>First Name:</label>
    <input type="text" class="form-control" name="firstname" placeholder="First Name" style="width: 55%;">
  </div>
  <div class="form-group">
    <label>Last Name:</label>
    <input type="text" class="form-control" name="lastname" placeholder="Last Name" style="width: 45%;">
  </div>
  <div class="form-group">
    <label>Contact Number:</label>
    <input type="text" class="form-control" name="phone" placeholder="Contact Number" style="width: 45%;">
  </div>
  <div class="form-group">
    <label>Description:</label><br>
    <textarea name="body" rows="6" cols="50" placeholder="Enter Description"></textarea>
  </div>
  <div class="form-group">
    <label>Tags:</label>
    <select name="tags[]" id="input-tags" style="width: 300px;" multiple>
      <option>Add a Tag</option>
    </select>
  </div>
  <input class="btn btn-success" type="submit" value="Submit">
  <a href="/home" type="button" class="btn btn-warning">Back</a>
  </form>
  </div>
  </div>
  <br>
     </div>
   </div>
</div>

    <script src="//code.jquery.com/jquery-1.11.3.min.js"></script>  
    <script src="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.3/js/select2.min.js"></script>

 <script>
 $(document).ready(function() {
  $(".select2basic").select2();
});
 $("#input-tags").select2({
  tags: true
});
     </script>
</html>
