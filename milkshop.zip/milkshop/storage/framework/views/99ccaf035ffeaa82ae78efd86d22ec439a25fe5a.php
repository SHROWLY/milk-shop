<?php $__env->startSection('content'); ?>
<div class="container" style="padding-bottom: 15px;">
    <a href="/home" type="button" class="btn btn-default" >Back</a>
</div>
<div class="container">
    <div class="row">
   <?php $__currentLoopData = $areas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="col-xs-12 col-sm-6 col-md-6">
            <div class="well well-sm">
                <div class="row">
                    <div class="col-sm-6 col-md-4">
                    <?php if($user->avatar): ?> 
                        <img src="/<?php echo e($user->avatar); ?>" alt="" class="img-rounded img-responsive" style="width: 200px;"/>
                    <?php endif; ?>
                    </div>
                    <div class="col-sm-6 col-md-8">
                        <h4><?php echo e($user->first_name); ?> <?php echo e($user->last_name); ?></h4>
                        <p>
                        <small><cite><i class="glyphicon glyphicon-map-marker">
                        </i> <?php echo e($user->area->name); ?></cite></small>
                            <i class="glyphicon glyphicon-user"></i><a href="/userposts=<?php echo e($user->id); ?>"><?php echo e($user->username); ?></a>
                            <br />
                            <i class="glyphicon glyphicon-time"></i><?php echo e($user->created_at); ?></p>
                        <!-- Split button -->
                        <a href="/userposts=<?php echo e($user->id); ?>" type="button" class="btn btn-info" >View Person</a>
                    </div>
                </div>
            </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('header-styles'); ?>
<style type="text/css">
            .glyphicon {  margin-bottom: 10px;margin-right: 10px;}
            small {
            display: block;
            line-height: 1.428571429;
            color: #999;
            }
</style>
<link rel="stylesheet" href="//cdnjs.cloudflare.com/ajax/libs/chosen/1.4.2/chosen.min.css">
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>